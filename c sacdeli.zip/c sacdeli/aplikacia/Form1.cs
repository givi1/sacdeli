﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aplikacia
{
    public partial class Form1 : Form
    {
        static List<string> names = new List<string>();
        BindingSource namesBindingSourse = new BindingSource();

        public Form1()
        {
            InitializeComponent();
        }

        internal void receiveDate(string newName)
        {
            names.Add(newName);
        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            namesBindingSourse.DataSource = names;
            listBox1.DataSource = namesBindingSourse;
        }

        private void Form1_Activated(object sender, EventArgs e)
        {
            namesBindingSourse.ResetBindings(false);
        }
    }
}
